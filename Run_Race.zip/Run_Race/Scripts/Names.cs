﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Names : MonoBehaviour
{
    public static string[] BotNames = { "Bot1", "Bot2", "Bot3" };
}
